#%%
import numpy as np
import pandas as pd
from time import sleep, strftime
from py5paisa import FivePaisaClient
from py5paisa.strategy import *
from py5paisa.logging import log_response
from datetime import datetime, timedelta
from datetime import date
import requests
from pytz import timezone 
from cred import *
import os



from datetime import datetime

def getOptionData(symbol = 'NIFTY', fromDate = '2018-12-25', fromTime = '09:20:00', toDate = '2018-12-25', toTime='15:35:00', expiry='02DEC2021' ):
    baseURL = 'https://opstra.definedge.com/api/optionsimulator/optionchain/'
    currentDate = fromDate + " "+ fromTime
    datetime_object_current = datetime.strptime(currentDate, '%Y-%m-%d %X')
    timestamp_current = int(datetime.timestamp(datetime_object_current))
    #print(timestamp_current)
    fivemin_timestamp = 300
    endDate = toDate + " "+ toTime
    datetime_object_endDate = datetime.strptime(endDate, '%Y-%m-%d %X')
    timestamp_end = int(datetime.timestamp(datetime_object_endDate))
    #print(timestamp_end)
    final_data = {}
    while (timestamp_current < timestamp_end):
        dt_object = datetime.fromtimestamp(timestamp_current)
        
        only_time = dt_object.time()
        timeparts = str(only_time).split(":")
        if (9 <= int(timeparts[0]) <= 15):
            #print(only_time)
            #url = baseURL + str(timestamp_current)+"&"+symbol+"&"+(datetime.fromtimestamp(timestamp_current).strftime('%d%b%Y')).upper()
            url = baseURL + str(timestamp_current)+"&"+symbol+"&"+ expiry
            
            #print(url)
            tempData = downloaddata(url)
            if tempData is not None:
                final_data[str(dt_object)] = tempData
                #print(dt_object)
                #print(url)
        timestamp_current = timestamp_current + fivemin_timestamp    
    return final_data

import requests
import json
def downloaddata(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; Rigor/1.0.0; http://rigor.com)",
        "Accept": "*/*"
    }
    url = url
    r = requests.get(url, headers=headers)
    
    if(r.status_code == 200):
        json_data = json.loads(r.content)
        return json_data;
    else:
        return None;
    
def jsonDump(symbol, fromDate, toDate, expiry,data):
    # the json file where the output must be stored
    fileName = symbol+"_"+str(fromDate)+"_"+str(toDate)+"_"+str(expiry)+'.json'
    out_file = open(fileName, "w")

    json.dump(data, out_file, indent = 6)

    out_file.close()
    

def getexpires():
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; Rigor/1.0.0; http://rigor.com)",
        "Accept": "*/*"
    }
    url = 'https://opstra.definedge.com/api/optionsimulator/simulatorexpiries'
    r = requests.get(url, headers=headers)
    
    if(r.status_code == 200):
        json_data = json.loads(r.content)
        return json_data;
expires_list = getexpires()

def callprice(optionchain,strikeprice):
    a=pd.DataFrame(optionchain)
    price=float(a[a['Strikes']==strikeprice]['CallLTP'])
    return price

def putprice(optionchain,strikeprice):
    a=pd.DataFrame(optionchain)
    price=float(a[a['Strikes']==strikeprice]['PutLTP'])
    return price


def readJson(symbol, fromDate, toDate,expiry, fromTime, toTime):
    fileName = symbol+"_"+str(fromDate)+"_"+str(toDate)+"_"+str(expiry)+'.json'
    if  not os.path.isfile(fileName):
        print("Downloading Data")
        data = getOptionData(symbol, fromDate,fromTime, toDate,toTime, expiry)
        jsonDump(symbol,  fromDate,toDate,expiry, data)
    f = open(fileName)
    # returns JSON object as
    # a dictionary
    data = json.load(f)
    f.close()
    return data

df_writeData = pd.DataFrame(columns=['Expiry', 'Date', 'Total Profit Booked'])


profit=[]
for sample in range(0, len(expires_list)):
    expiry = expires_list[sample]
    if '2021' in expires_list[sample]:

        for j in range(0,7):
            expirydate = datetime.strptime(expiry, '%d%b%Y')
            enddate = expirydate - timedelta(days=j)
            startdate = expirydate - timedelta(days=j)
            symbol = 'BANKNIFTY'
            fromDate = startdate.strftime('%Y-%m-%d')
            fromTime = '09:30:00'
            toDate = enddate.strftime('%Y-%m-%d')
            toTime='15:35:00'
            print(expiry)
            print(enddate.date())
            print(startdate.date())
            try:
                #dataJson = readJson(symbol, fromDate, toDate, expiry)
                present_expiry = readJson(symbol, fromDate, toDate, expiry, fromTime, toTime)
                p_keys=list(present_expiry.keys())

                start=0
                x=present_expiry[p_keys[start]]['spotPrice']
                print(x)

                control1=0
                control2=0
                req_list_PE_strikeprice=round(x/100)*100
                req_list_CE_strikeprice=round(x/100)*100
                ce_lastrate=callprice(optionchain=present_expiry[p_keys[0]]['optionchaindata'],strikeprice=req_list_CE_strikeprice)
                pe_lastrate=putprice(optionchain=present_expiry[p_keys[0]]['optionchaindata'],strikeprice=req_list_PE_strikeprice)
                temp_ce=ce_lastrate
                temp_pe=pe_lastrate
                temp_pe_last=0
                temp_ce_last=0
                ce_lastrate_old=ce_lastrate
                pe_lastrate_old=pe_lastrate
                Stop_loss1=ce_lastrate*1.2
                Stop_loss2=pe_lastrate*1.2
                for i in range(0,len(p_keys)):
                    ce_lastrate=callprice(optionchain=present_expiry[p_keys[i]]['optionchaindata'],strikeprice=req_list_CE_strikeprice)
                    pe_lastrate=putprice(optionchain=present_expiry[p_keys[i]]['optionchaindata'],strikeprice=req_list_PE_strikeprice)
                    if ce_lastrate<ce_lastrate_old and control1==0:
                        Stop_loss1=ce_lastrate*1.2
                        ce_lastrate_old=ce_lastrate
                    if ce_lastrate>Stop_loss1 and control1==0:
                        control1=1
                        temp_ce_last=ce_lastrate
                    if pe_lastrate<pe_lastrate_old and control2==0:
                        Stop_loss2=pe_lastrate*1.2
                        pe_lastrate_old=pe_lastrate
                    if pe_lastrate>Stop_loss2 and control2==0:
                        control2=1
                    
                        temp_pe_last=pe_lastrate
                    if control1==1 and control2==1:
                        break
                if temp_ce_last==0:
                    temp_ce_last=callprice(optionchain=present_expiry[p_keys[-1]]['optionchaindata'],strikeprice=req_list_CE_strikeprice)
                if temp_pe_last==0:
                    temp_pe_last=putprice(optionchain=present_expiry[p_keys[-1]]['optionchaindata'],strikeprice=req_list_PE_strikeprice)
                
                profit=profit+[temp_ce+temp_pe-temp_ce_last-temp_pe_last]
            except Exception:
                pass

# %%
